import pickle
from nltk.classify import ClassifierI
from nltk.probability import FreqDist, ConditionalFreqDist
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
import xlrd
import nltk
import xlsxwriter
import re

def bag_of_words(words):
	'''
	>>> bag_of_words(['the', 'quick', 'brown', 'fox'])
	{'quick': True, 'brown': True, 'the': True, 'fox': True}
	'''	
	return dict([(word, True) for word in words])

class MaxVoteClassifier(ClassifierI):
	def __init__(self, *classifiers):
		self._classifiers = classifiers
		self._labels = sorted(set(itertools.chain(*[c.labels() for c in classifiers])))
	def labels(self):
		return self._labels
	def classify(self, feats):
		counts = FreqDist()
		for classifier in self._classifiers:
			counts.inc(classifier.classify(feats))
		return counts.max()


with open('mv_classifier.pk','rb') as input:
    mv_classifier=pickle.load(input)
print "pickle loaded"



wb = xlrd.open_workbook('input1.xlsx'); # Create object to read
book = xlsxwriter.Workbook('Category.xlsx'); # Create object to write
sheet1 = book.add_worksheet(); #sheet name for new file
sh = wb.sheet_by_index(0); # read file, which sheet??
for rownum in range(sh.nrows):    # reading row by row
    for colnum in range(sh.ncols):  # reading column by column
        Data = sh.cell(rownum,colnum).value;   # sh.cell(0,0).value
        Data=unicode(Data);
        Data=Data.encode('mbcs');#french encoding
        Data=str(Data);
        #Data=Data.strip('=');
        Data = re.sub(r'(?i)\b((?:https?://|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}/)(?:[^\s()<>]+|\(([^\s()<>]+|(\([^\s()<>]+\)))*\))+(?:\(([^\s()<>]+|(\([^\s()<>]+\)))*\)|[^\s`!()\[\]{};:\'".,<>?������]))', '', Data)
        Data=re.sub(r'[?|$|.|!]',r'',Data);
        Data=re.sub(r'[^\x00-\x7f]',r' ',Data)
        sheet1.write(rownum, colnum, Data);
        tokenize=word_tokenize(Data);
        lower=[w.lower() for w in tokenize];
        stopwords = nltk.corpus.stopwords.words('french');
        content = [w for w in lower if w.lower() not in stopwords];
        bag=bag_of_words(content);
        mc=mv_classifier.classify(bag)        
        if mc:
           mcitem=str(mc);                    
           colnum=colnum+1;           
           sheet1.write(rownum, colnum, mcitem);        

book.close()        
