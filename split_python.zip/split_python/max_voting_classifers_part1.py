from nltk.corpus.reader import CategorizedTaggedCorpusReader
from nltk.probability import FreqDist, ConditionalFreqDist
from nltk.classify.maxent import MaxentClassifier
from nltk.classify import ClassifierI
from nltk.classify import NaiveBayesClassifier
from nltk.classify import DecisionTreeClassifier
from nltk.classify.util import accuracy
from nltk.corpus import stopwords
import itertools
import collections
import pickle
from nltk import metrics
reuters = CategorizedTaggedCorpusReader('D:/21.NLTK_Interns/Voting_split/train_data/64train', '(training|test).*',cat_file='cats.txt')
'Replace the above path with the path where the train data set is prsent' 


def bag_of_words(words):
	'''
	>>> bag_of_words(['the', 'quick', 'brown', 'fox'])
	{'quick': True, 'brown': True, 'the': True, 'fox': True}
	'''	
	return dict([(word, True) for word in words])
      
def label_feats_from_corpus(corp, feature_detector=bag_of_words):
	label_feats = collections.defaultdict(list)
	
	for label in corp.categories():
		for fileid in corp.fileids(categories=[label]):
			feats = feature_detector(corp.words(fileids=[fileid]))
			label_feats[label].append(feats)
	
	return label_feats
      

def split_label_feats(lfeats, split=0.75):
	train_feats = []
	test_feats = []
	
	for label, feats in lfeats.iteritems():
		cutoff = int(len(feats) * split)
		train_feats.extend([(feat, label) for feat in
		feats[:cutoff]])
		test_feats.extend([(feat, label) for feat in
		feats[cutoff:]])
	return train_feats, test_feats


class MaxVoteClassifier(ClassifierI):
	def __init__(self, *classifiers):
		self._classifiers = classifiers
		self._labels = sorted(set(itertools.chain(*[c.labels() for c in classifiers])))
	def labels(self):
		return self._labels
	def classify(self, feats):
		counts = FreqDist()
		for classifier in self._classifiers:
			counts.inc(classifier.classify(feats))
		return counts.max()


def precision_recall(classifier, testfeats):
	refsets = collections.defaultdict(set)
	testsets = collections.defaultdict(set)
	for i, (feats, label) in enumerate(testfeats):
		refsets[label].add(i)
		observed = classifier.classify(feats)
		testsets[observed].add(i)
	precisions = {}
	recalls = {}
	for label in classifier.labels():
		precisions[label] = metrics.precision(refsets[label],testsets[label])
		recalls[label] = metrics.recall(refsets[label], testsets[label])
	return precisions, recalls

def save_object(obj,filename):
	with open(filename,'wb') as output:
		pickle.dump(obj,output,1)
	return obj
	    




lfeats_nb = label_feats_from_corpus(reuters)

train_feats_nb, test_feats_nb = split_label_feats(lfeats_nb)

nb_classifier = NaiveBayesClassifier.train(train_feats_nb)
print "NaiveBayesClassifier Done"

dt_classifier = DecisionTreeClassifier.train(train_feats_nb,binary=False, entropy_cutoff=0.8, depth_cutoff=5, support_cutoff=30)
print "DecisionTreeClassifier Done"

me_classifier = MaxentClassifier.train(train_feats_nb,algorithm='iis', trace=0, max_iter=6, min_lldelta=0.5)
print "MaxentClassifier Done"

mv_classifier = MaxVoteClassifier(nb_classifier, dt_classifier, me_classifier)

save_object(mv_classifier,'mv_classifier.pk')

mv_precisions, mv_recalls = precision_recall(mv_classifier, test_feats_nb)
print "Accuracy: %s" % str(accuracy(mv_classifier, test_feats_nb))
print " POS precision: %s" % str(mv_precisions['POS'])
print " NEG precision: %s" % str(mv_precisions['NEG'])
print " NEU precision: %s" % str(mv_precisions['NEU'])
print " POS recalls: %s" % str(mv_recalls['POS'])
print " NEG recalls: %s" % str(mv_recalls['NEG'])
print " NEU recalls: %s" % str(mv_recalls['NEU'])

print "THE CLASSIFIERS HAS SUCCESSFULLY PICKLED. PLEASE RUN THE SECOND PART OF THIS PROGRAM"

